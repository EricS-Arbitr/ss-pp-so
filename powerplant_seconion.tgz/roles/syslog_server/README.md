# Syslog Server Role

## Description
Configures a Linux host as the range's central rsyslog collector. Installs rsyslog (no-op on Ubuntu Desktop/Server, which ship with it), opens UDP **and** TCP port 514, and writes incoming messages to per-host files at `/var/log/remote/<hostname>/syslog.log`. Local rsyslog/journald messages keep their normal `/var/log/syslog` path; only remote events land under `/var/log/remote/`, one directory per sender so host attribution survives the relay.

**Nothing tails this store.** Splunk was removed 2026-09-09 and `/var/log/remote/` is now a local artifact only — a realistic enterprise construct and a plausible attacker target, not a SIEM feed. Linux hosts ship their own syslog to Security Onion via the Elastic Agent system integration, so relaying these files would place every message in SO twice by two routes. Devices that cannot run an agent (pfSense, VyOS) dual-send: to `:514` here for this store, and to Elastic Agent listeners on this same host that parse them into Security Onion.

## Variable Definition Location
Variables for this role are defined in:
- **group_vars/all.yml** — `syslog_server_ip` (informational on the server; the role binds to all interfaces)
- **inventory** — host membership in the `[syslog]` group selects which host(s) get this role

## Required Variables

None — the role itself has no required variables. Membership in `[syslog]` is what targets the role at a host.

## Optional Variables

This role does not currently expose tunables. If you need to change the listen port, file layout, or transports, edit `templates/30-remote.conf.j2`.

## Companion Variables (used elsewhere, but related)

| Variable | Where | Description |
|----------|-------|-------------|
| syslog_server_ip | group_vars/all.yml | IP that clients forward to. The syslog client plays in `playbooks/00-baseline.yml` (Linux, VyOS, pfSense) reference this. The server itself binds to `*:514` so this var is informational on the server side. |

## Prerequisites
- The host runs Ubuntu (`apt`-managed). The Linux NM pre-config play and `common` role run before this one.
- Network reachability from every sender to `syslog_server_ip:514` is in place — verified end-to-end during the routing fixes (corp/DMZ/OT all reach the PP-Services subnet that pp-syslog lives on).
- The host runs an Elastic Agent carrying the pfSense and Custom-UDP-Logs integrations, which is how network gear reaches Security Onion.

## Notes
- Listens on **both** UDP and TCP 514. UDP matches pfSense/VyOS defaults; TCP is available for any client configured to send over TCP. Most clients in this range use UDP for simplicity.
- The rsyslog filter (`if $fromhost-ip != '127.0.0.1' then { ... stop }`) ensures remote events land **only** in `/var/log/remote/<hostname>/syslog.log` and don't also flow into `/var/log/syslog` on the collector. Local kernel/cron/etc. messages keep their normal path because they originate from `127.0.0.1`.
- Per-host directory layout is intentional: the directory name is the host attribution for anything reading this store, so events are identifiable by **sender** (e.g., `pp-internal-router`, `pp-ot-firewall`) rather than collapsing into pp-syslog.
- File mode is `0640` (group `adm`), directory mode `0755`, owner `syslog:adm` — matches Ubuntu's stock log layout.
- Idempotent — re-runs only restart rsyslog if `30-remote.conf` content changed (handler `restart rsyslog`).
- pp-isp-router is explicitly excluded from the VyOS client play (`hosts: vyos:vyos_routes_only:!pp-isp-router`) because it represents the upstream ISP; sending its logs into the corp SIEM would break scenario fiction.

## Related upstream gap
See `UPSTREAM_FIXES.md`, entry **2026-05-29 · gap · range-development-ansible has no central syslog collector role** — this role is the PowerPlant overlay's reference implementation and could be lifted into the shared repo verbatim.
